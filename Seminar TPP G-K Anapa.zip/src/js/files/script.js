// Подключение функционала "Чертогов Фрилансера"
import { isMobile } from "./functions.js";
// Подключение списка активных модулей
import { flsModules } from "./modules.js";


function headerScroll() {
    const header = document.querySelector('.header');
    let scrollPos = window.scrollY;
 
    if(scrollPos >= 1) {
       header.classList.add('scrolling');
    } else {
       header.classList.remove('scrolling');
    }
 }
 
 window.addEventListener("scroll", headerScroll);
 
 document.addEventListener("DOMContentLoaded", headerScroll);